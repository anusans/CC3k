/*
 * enemy.cc
 * CS246 Assignment 5 (CC3k)
 * Chaewoon Park (c39park) & Anusan Sivakumaran (a26sivak)
 */

#include "enemy.h"

//Constructor
Enemy::Enemy(int r, int c, int hp, int atk, int def): Character(r, c, hp, atk, def) { }

//Destructor
Enemy::~Enemy() { }

//Methods
//None. Abstract class.

